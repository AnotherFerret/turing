#include "definition.h"
#ifndef H_GL_LOG
#define H_GL_LOG
void creation_log_latex();
void ecrire_log(T_machine *T);
void fermeture_log();
void ecrire_ruban(Ruban **r,int entier);
#endif
