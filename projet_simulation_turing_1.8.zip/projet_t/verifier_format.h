#include "definition.h"
#ifndef H_GL_CHECK
#define H_GL_CHECK


int verifier_transition_non_vide(char* path);
int verifier_format_etat_alphabet(char* path);
int verifier_format_transition_ruban(char* path);
#endif
