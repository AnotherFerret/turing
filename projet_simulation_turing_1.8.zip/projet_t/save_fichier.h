#include "definition.h"
#ifndef H_GL_SAVE
#define H_GL_SAVE
void tri_a_bulle_c(int *t,int n);
void conversion_donne_fichier(char* path, Info_machine I);
#endif
